//
//  FaceCaptcha.h
//  FaceCaptcha
//
//  Copyright © 2019-2023 Oiti. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for FaceCaptcha.
FOUNDATION_EXPORT double FaceCaptchaVersionNumber;

//! Project version string for FaceCaptcha.
FOUNDATION_EXPORT const unsigned char FaceCaptchaVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FaceCaptcha/PublicHeader.h>
